package com.example.metro_go;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Ensure the correct layout is set
        setContentView(R.layout.login); // Make sure 'login' matches your layout file name

        // Initialize the Sign Up Button
        Button signUpButton = findViewById(R.id.signup); // Ensure this ID exists in login.xml
        signUpButton.setOnClickListener(v -> {
            // Navigate to SignUpActivity
            Intent intent = new Intent(LoginActivity.this, sign_up_activity.class);
            startActivity(intent);
        });
    }
}
