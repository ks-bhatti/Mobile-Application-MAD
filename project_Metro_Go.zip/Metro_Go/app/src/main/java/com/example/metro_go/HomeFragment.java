package com.example.metro_go;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class HomeFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // Initialize the Login Button
        Button loginButton = view.findViewById(R.id.login_button);
        loginButton.setOnClickListener(v -> {
            // Navigate to LoginActivity
            Intent intent = new Intent(getActivity(), LoginActivity.class);
            startActivity(intent);
        });

        // Initialize Grid Activity Click Listeners
        view.findViewById(R.id.activity_1).setOnClickListener(v -> {
            Toast.makeText(requireContext(), "Activity 1 Clicked", Toast.LENGTH_SHORT).show();
        });

        view.findViewById(R.id.activity_2).setOnClickListener(v -> {
            Toast.makeText(requireContext(), "Activity 2 Clicked", Toast.LENGTH_SHORT).show();
        });

        view.findViewById(R.id.activity_3).setOnClickListener(v -> {
            Toast.makeText(requireContext(), "Activity 3 Clicked", Toast.LENGTH_SHORT).show();
        });

        view.findViewById(R.id.activity_4).setOnClickListener(v -> {
            Toast.makeText(requireContext(), "Activity 4 Clicked", Toast.LENGTH_SHORT).show();
        });

        return view;
    }
}
