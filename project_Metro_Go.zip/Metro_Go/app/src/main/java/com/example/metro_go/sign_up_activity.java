package com.example.metro_go;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class sign_up_activity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up_activity);

        findViewById(R.id.btn_signup).setOnClickListener(v -> {
            finish();
        });
    }
}

