package com.example.metro_go;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize DrawerLayout and ListView
        drawerLayout = findViewById(R.id.drawer_layout);
        ListView navigationMenu = findViewById(R.id.navigation_menu);

        // Populate the ListView with menu items
        String[] menuItems = getResources().getStringArray(R.array.drawer_items);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_list_item_1, menuItems);
        navigationMenu.setAdapter(adapter);

        // Handle Menu Item Clicks
        navigationMenu.setOnItemClickListener((parent, view, position, id) -> {
            Fragment selectedFragment = null;
            switch (position) {
                case 0: // Home
                    selectedFragment = new HomeFragment();
                    Toast.makeText(MainActivity.this, "Home Selected", Toast.LENGTH_SHORT).show();
                    break;
                case 1: // Sync
                    Toast.makeText(MainActivity.this, "Sync Selected", Toast.LENGTH_SHORT).show();
                    break;
                case 2: // Settings
                    selectedFragment = new SettingsFragment();
                    Toast.makeText(MainActivity.this, "Settings Selected", Toast.LENGTH_SHORT).show();
                    BottomNavigationView bottomNavigationView2 = findViewById(R.id.bottom_navigation);
                    bottomNavigationView2.setSelectedItemId(R.id.nav_settings);

                    break;
            }
            if (selectedFragment != null) {
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container, selectedFragment)
                        .commit();
            }
            drawerLayout.closeDrawers(); // Close the drawer after item selection
        });

        // Hamburger Icon Click Listener
        ImageView btnHamburger = findViewById(R.id.btn_hamburger);
        btnHamburger.setOnClickListener(v -> {
            if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
                drawerLayout.closeDrawer(GravityCompat.START); // Close if open
            } else {
                drawerLayout.openDrawer(GravityCompat.START); // Open if closed
            }
        });

        // Initialize BottomNavigationView
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        // Set default fragment (HomeFragment)
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new HomeFragment())
                    .commit();
            bottomNavigationView.setSelectedItemId(R.id.nav_home); // Ensure Home is selected by default
        }

        // Bottom Navigation Click Listener
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            Fragment selectedFragment = null;


            if (item.getItemId() == R.id.nav_home) {
                selectedFragment = new HomeFragment();
            } else if (item.getItemId() == R.id.nav_notifications) {
                selectedFragment = new Notification_fragment();
            } else if (item.getItemId() == R.id.nav_qr_scanner) {
                selectedFragment = new QRScannerFragment();
            } else if (item.getItemId() == R.id.nav_contact) {
                selectedFragment = new RecentFragment();
            } else if (item.getItemId() == R.id.nav_settings) {
                selectedFragment = new SettingsFragment();
            }
            if (selectedFragment != null) {
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container, selectedFragment)
                        .commit();
            }
            return true;
        });
    }

    // Handle back button to close drawer if open
    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START); // Close the drawer if it is open
        } else {
            super.onBackPressed(); // Handle normal back button behavior
        }
    }
}
