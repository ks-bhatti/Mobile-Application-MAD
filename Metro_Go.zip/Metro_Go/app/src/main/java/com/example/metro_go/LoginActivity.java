package com.example.metro_go;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameInput, passwordInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        // Initialize inputs and buttons
        usernameInput = findViewById(R.id.username_input);
        passwordInput = findViewById(R.id.password_input);
        Button loginButton = findViewById(R.id.login);
        Button signUpButton = findViewById(R.id.signup);

        // Handle Login button click
        loginButton.setOnClickListener(v -> {
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Please enter both username and password!", Toast.LENGTH_SHORT).show();
            } else {
                // Retrieve stored credentials from SharedPreferences
                SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
                String registeredUsername = sharedPreferences.getString("username", null);
                String registeredPassword = sharedPreferences.getString("password", null);

                // Validate credentials
                if (username.equals(registeredUsername) && password.equals(registeredPassword)) {
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putBoolean("is_logged_in", true); // Set login state
                    editor.apply();

                    Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show();

                    // Navigate back to Home
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(this, "Invalid username or password!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Handle Sign Up button click
        signUpButton.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, sign_up_activity.class);
            startActivity(intent);
        });
    }
}
