package com.example.my_login;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;

import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.widget.Button;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText usernameInput, passwordInput;
    private CheckBox checkBoxStayLoggedIn;
    private Button loginWithCredentialButton, loginWithBadgeButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        // XML elements to Java objects
        usernameInput = findViewById(R.id.username_input);
        passwordInput = findViewById(R.id.password_input);
        checkBoxStayLoggedIn = findViewById(R.id.checkBoxStayLoggedIn);
        loginWithCredentialButton = findViewById(R.id.loginwithcredential);
        loginWithBadgeButton = findViewById(R.id.loginwithbudge);

        //onClickListener for login with credentials button
        loginWithCredentialButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleLoginWithCredentials();
            }
        });

        // onClickListener for login with badge button
        loginWithBadgeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleLoginWithBadge();
            }
        });
    }
    private void handleLoginWithCredentials() {
        // Get the username and password from the EditText fields
        String username = usernameInput.getText().toString();
        String password = passwordInput.getText().toString();
        boolean stayLoggedIn = checkBoxStayLoggedIn.isChecked();

        // Simple validation check (This can be expanded to connect to a backend or database)
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(MainActivity.this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
        } else if (username.equals("admin") && password.equals("admin123")) { // Dummy check
            // Login success
            Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
            if (stayLoggedIn) {
                // Handle staying logged in (you can save this state in SharedPreferences)
                Toast.makeText(MainActivity.this, "You will stay logged in", Toast.LENGTH_SHORT).show();
            }
        } else {
            // Invalid credentials
            Toast.makeText(MainActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
        }
    }

    private void handleLoginWithBadge() {
        // Handle login with a badge functionality
        Toast.makeText(MainActivity.this, "Login with Badge Clicked", Toast.LENGTH_SHORT).show();
        // Add your code for login with badge (like NFC or QR code handling)
    }
}